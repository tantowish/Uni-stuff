public class Subject {
    String namaSubject;
    int nilai[];
    public Subject(String namaSubject, int[] nilai){
        this.namaSubject = namaSubject;
        this.nilai = nilai;
    }
}
