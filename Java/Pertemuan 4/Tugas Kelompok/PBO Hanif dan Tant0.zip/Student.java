public class Student {
    String nama,num;
    public Student(String nama, String num){
        this.nama = nama;
        this.num = num;
    }
}
